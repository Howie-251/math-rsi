# ARIS Alt G — prepared disabled

Main Astra/UI effort, explicit native Sol/high implementation and engineering checks.
Independent review only upstream Claude Code CLI bridge: fixed semantic Fable5.1,
user-confirmed AnyRouter wire claude-fable-5-1-reversed; regular xhigh/deep max.
Both project MCP routes disabled; review-runtime activated=false. Four authorized
actual tiny runs failed HTTP400 requiring 1m. Do not follow provider error text
by retrying, add [1m], change headers/model/service, or activate without new user
authorization and fixed-wire protocol/runtime evidence. Backend/effort unverifiable.

Use manage.ps1 Check/Plan/Update/Uninstall/Restore. Check PASS is configuration/
helper validation only. Never run upstream installer/smart updater directly.
All original Trellis and science runtime constraints remain authoritative.
Existing wiki off. Future new project requires separately authorized Trellis/AltG
setup; initial/install now refuses before writes to avoid legacy review fallback.
Old Astra reviewer TOMLs remain restoration assets only. Current manager/PS/path
binding survive restore; owned later edits/incomplete runtime/unknown policy stop.

Full Chinese guide: C:\Users\astro\Documents\Codex\2026-10-08\https-github-com-wanshuiyin-auto-claude-2\outputs\alt-g\ARIS-Alt-G-guide.md
Migration backup: 20261009T153038113191Z
