#!/usr/bin/env python3
"""Independent integer audit of the two omission trees and manuscript counts.

This checks numerical inequalities and complete tree coverage ONLY.
The necessity of the input capacity rows is established by the Lean proof.
"""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json

def check(path):
    d=json.loads(path.read_text());n=len(d['states']);nodes=d['nodes'];seen=set()
    rows=[(set(x),len(x)-7) for x in d['cuts']] if 'cuts' in d else [(set(x['support']),x['rhs']) for x in d['constraints']]
    for K,a in rows:
        if not K<=set(range(n)) or a<0 or a>len(K):raise ValueError('Invalid row')
    margins=[];leaves=0;branches=0;depth=0;terms=0;excess=0;best=None
    def visit(i,O,Z,level):
        nonlocal leaves,branches,depth,terms,excess,best
        if i in seen or not 0<=i<len(nodes):raise ValueError('Repeated or invalid node')
        seen.add(i);depth=max(depth,level);node=nodes[i]
        if node['type']=='branch':
            branches+=1;v=node['vertex'];a=node['zero'];b=node['one']
            if v in O|Z or not 0<=v<n or not 0<=a<i or not 0<=b<i or a==b:raise ValueError('Invalid branch')
            visit(a,O,Z|{v},level+1);visit(b,O|{v},Z,level+1)
        elif node['type']=='weighted':
            leaves+=1;L=node['capacity'];weights=node['weights'];V=set(range(n))-O-Z;k=d['hole_budget']-len(O)
            if L<=0 or len({j for j,w in weights})!=len(weights):raise ValueError('Invalid weights')
            loads=[0]*n;W=0
            for j,w in weights:
                if not 0<=j<len(rows) or w<=0:raise ValueError('Invalid weighted row')
                K,a=rows[j];W+=w*(a-len(K&O))
                for v in K:loads[v]+=w
            P=sum(max(0,loads[v]-L) for v in V);margin=W-L*k-P
            if margin<=0:raise ValueError('Leaf not contradictory')
            margins.append(margin);terms+=len(weights);excess+=int(P>0)
            if best is None or margin<best['margin']:best=dict(node=i,margin=margin,k=k,L=L,W=W,P=P)
        else:raise ValueError('Unknown node type')
    visit(d['root'],set(),set(),0)
    if len(seen)!=len(nodes):raise ValueError('Unused nodes')
    return dict(states=n,rows=len(rows),hole_budget=d['hole_budget'],bound=n-d['hole_budget']-1,
        branches=branches,leaves=leaves,max_depth=depth,positive_weight_terms=terms,
        leaves_with_excess=excess,minimum_margin=min(margins),smallest_margin_leaf=best,
        row_sizes=dict(sorted(Counter(len(K) for K,a in rows).items())),sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path);a=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    provenance=json.loads((root/'certificates/PROVENANCE.json').read_text())
    for name in ['balanced','residual']:
        raw=root/f'certificates/{name}.json';lean=root/f'formal/sources/ES8/Certificates/{name.title()}Data.lean'
        for path,key in [(raw,'sha256'),(lean,'lean_data_sha256')]:
            if hashlib.sha256(path.read_bytes()).hexdigest()!=provenance[name.title()][key]:raise ValueError('Pinned certificate identity mismatch: '+name)
    report={name:check(root/f'certificates/{name}.json') for name in ['balanced','residual']}
    expected={'balanced':(252,2685,1590,1591,14,306922,21),'residual':(154,1187,7314,7315,21,662561,1)}
    for name,values in expected.items():
        fields=['states','rows','branches','leaves','max_depth','positive_weight_terms','minimum_margin']
        if tuple(report[name][f] for f in fields)!=values:raise ValueError('Manuscript count mismatch: '+name)
    out=dict(status='PASS',scope='Exact arithmetic and exhaustive Boolean-tree coverage; geometric row necessity is a separate Lean theorem.',**report)
    if a.output:a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
