#!/usr/bin/env python3
"""Independent, exact audit of all octagon finite certificates, without Lean.

Reconstructs both state universes and every directed difference from cells;
checks all six orders for each triple of all 3,849 cyclic families; validates
the 23 JSON block maps and their Lean representations; compares the literal
Lean arithmetic data with JSON; and replays both complete omission trees.
The geometric lemmas connecting these finite conditions to real points are
proved in the paper and Lean. This Python program is not a verified checker.
"""
from pathlib import Path
from itertools import combinations, permutations, product
import argparse, ast, copy, json, re, tempfile, time
from check_octagon_arithmetic import check as check_tree


def require(ok, message):
    if not ok:
        raise ValueError(message)


def rejects(call):
    try:
        call()
    except ValueError:
        return
    raise ValueError('A deliberately invalid certificate was accepted')


def literal(text, declaration):
    """Read the single numeric string in one named Lean data declaration."""
    start = text.index('def ' + declaration + ' ')
    start = text.index('"', start) + 1
    end = text.index('"', start)
    raw = text[start:end]
    raw = raw.replace('\\n', '\n')
    require(re.fullmatch(r'[0-9]+(?: [0-9]+)*(?:\n[0-9]+(?: [0-9]+)*)*', raw) is not None,
            'Noncanonical numeric data string')
    return [[int(v) for v in line.split()] for line in raw.splitlines()]


def profiles(w, h):
    return [s for s in product(range(h + 1), repeat=w)
            if all(a >= b for a, b in zip(s, s[1:]))]


def cells(s):
    return {(i + 1, y) for i, h in enumerate(s) for y in range(1, h + 1)}


def certify_cycles(states, rows, cycles, row_ids, stored_boxes):
    sets = list(map(cells, states))
    n = len(states)
    differences = [[b - a for b in sets] for a in sets]
    boxes = []
    for ds in differences:
        for d in ds:
            boxes.append([1, min(x for x,y in d), max(x for x,y in d),
                          min(y for x,y in d), max(y for x,y in d)] if d else [0]*5)
    require(boxes == stored_boxes, 'Stored directed boxes differ from cell reconstruction')
    require(len(cycles) == len(row_ids) == len(set(row_ids)), 'Cycle coverage mismatch')
    count = excluded = forced = 0
    for rid, cyc in zip(row_ids, cycles):
        support, demand = rows[rid]
        require(len(cyc) == len(set(cyc)) and set(cyc) == support, 'Cycle support mismatch')
        require(demand == len(cyc) - 7, 'Cycle demand mismatch')
        for triple in combinations(cyc, 3):
            for perm in permutations(range(3)):
                count += 1
                a, b, c = (triple[i] for i in perm)
                ab, bc, ac = (differences[a][b], differences[b][c], differences[a][c])
                if not ab or not bc or not ac:
                    excluded += 1
                    continue
                # In cap,cup coordinates, blocking cap growth forces a cup,
                # and blocking cup growth forces a cap. Parity converts the
                # chronological sign into positive cyclic orientation.
                odd = sum(perm[i] > perm[j] for i in range(3) for j in range(i+1,3)) % 2
                coord = 1 if odd else 0
                require(max(z[coord] for z in bc) <= min(z[coord] for z in ab),
                        f'Unforced cyclic sign in row {rid}, triple {triple}, order {perm}')
                forced += 1
    return dict(families=len(cycles), triple_orders=count, empty_difference_orders=excluded,
                forced_orders=forced, directed_boxes=len(boxes))


def certify_blocks(states, rows, constraints, text):
    pattern = (r'\{ rowId := (\d+), support := (\[[^\]]*\]), '
               r'thresholds := (\[[^\]]*\]), active := (\[[^\]]*\]) \}')
    blocks = {int(i):(ast.literal_eval(s),ast.literal_eval(t),ast.literal_eval(a))
              for i,s,t,a in re.findall(pattern,text)}
    ids = [i for i,r in enumerate(constraints) if r['kind']=='baek_block']
    require(set(blocks)==set(ids) and len(ids)==23, 'Block row coverage mismatch')
    universe = {tuple(s):i for i,s in enumerate(states)}
    sets = list(map(cells, states))
    source = profiles(6,2)  # source row widths, not column heights
    require(len(source)==28, 'Wrong source universe')
    total_growth_tests = 0
    for rid in ids:
        f = constraints[rid]['map']
        require(len(f)==6 and all(len(r)==3 and 0<=r[0]<r[1]<r[2]<=4 for r in f),
                'Invalid map dimensions or row thresholds')
        for a,b in zip(f,f[1:]):
            require(all(b[j]<=a[j] for j in range(3)), 'Nonmonotone map')
            require(all(b[j]<=a[j-1]+1 for j in (1,2)), 'Invalid cross-row gap')
        image = []
        for widths in source:
            mapped = [f[j][widths[j]] for j in range(6)]
            require(all(a>=b for a,b in zip(mapped,mapped[1:])), 'Image is not an ideal')
            heights = tuple(sum(v>=x for v in mapped) for x in range(1,5)) + (0,)
            require(heights in universe, 'Block leaves the residual universe')
            image.append(universe[heights])
        support, demand = rows[rid]
        require(len(set(image))==28 and set(image)==support and demand==6, 'Wrong block image/demand')
        ls, thresholds, active = blocks[rid]
        require(set(ls)==support and len(ls)==len(support), 'Lean block support mismatch')
        expected_active = {(x,j+1) for j,row in enumerate(f) for x in range(row[0]+1,row[2]+1)}
        require(thresholds==[row[1] for row in f] and set(active)==expected_active
                and len(active)==len(expected_active), 'JSON/Lean block representation mismatch')
        for a,b in product(support,repeat=2):
            require(sets[b]-sets[a] <= expected_active, 'Uncovered directed difference')
        rank = lambda z: 1 if z[0]<=thresholds[z[1]-1] else 2
        for a in support:
            for z,w in product(expected_active,repeat=2):
                if z in sets[a] and w not in sets[a] and z[0]<w[0]:
                    total_growth_tests += 1
                    require(rank(z)<rank(w), 'Compressed cap growth fails')
    return dict(blocks=len(ids), source_states=len(source), occupied_capacity=22,
                checked_growth_implications=total_growth_tests, row_ids=ids)


def compare_arithmetic(d, rows, text):
    require(literal(text,'rows')==[[sum(1<<v for v in K),a] for K,a in rows],
            'Lean/JSON capacity rows differ')
    leaves = literal(text,'leaves')
    tree = literal(text,'tree')
    require(len(leaves)==len(tree)==len(d['nodes']), 'Lean/JSON tree size mismatch')
    for i,node in enumerate(d['nodes']):
        if node['type']=='weighted':
            expected=[node['capacity']]+[x for pair in node['weights'] for x in pair]
            require(tree[i]==[0,i] and leaves[i]==expected, 'Lean/JSON leaf mismatch')
        else:
            require(tree[i]==[1,node['vertex'],node['zero'],node['one']], 'Lean/JSON split mismatch')
    # Decode.tree returns its final node; JSON identifies the root explicitly.
    require(d['root']==len(tree)-1, 'Tree root mismatch')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    source=root/'formal/sources'
    start=time.monotonic()
    report={}
    for name,w,h in [('balanced',5,5),('residual',4,6)]:
        d=json.loads((root/f'certificates/{name}.json').read_text())
        expected=set(profiles(w,h))
        if name=='residual':
            expected={s+(0,) for s in expected if s[0]<6 or s[1]==6}
        require(len(d['states'])==len(expected) and set(map(tuple,d['states']))==expected,
                'State universe mismatch')
        catalog_text=(source/f'ES8{name.title()}CatalogData.lean').read_text()
        catalog=ast.literal_eval(re.search(r'def catalog[^\n]*:= (\[.*\])',catalog_text)[1])
        require(catalog==d['states'], 'Lean/JSON catalogue order mismatch')
        rows=[(set(s),len(s)-7) for s in d['cuts']] if name=='balanced' else [
            (set(r['support']),r['rhs']) for r in d['constraints']]
        path=source/('ES8CycleData.lean' if name=='balanced' else 'ES8ResidualCycleData.lean')
        text=path.read_text()
        cycles=literal(text,'cycles')
        ids=list(range(len(rows))) if name=='balanced' else ast.literal_eval(
            re.search(r'def cycleRows : List Nat := (\[[^\]]*\])',text)[1])
        report[name]=certify_cycles(d['states'],rows,cycles,ids,literal(text,'boxes'))
        bad=copy.deepcopy(cycles);bad[0]=list(reversed(bad[0]))
        rejects(lambda:certify_cycles(d['states'],rows,bad,ids,literal(text,'boxes')))
        bad=copy.deepcopy(cycles);bad[0][1]=bad[0][0]
        rejects(lambda:certify_cycles(d['states'],rows,bad,ids,literal(text,'boxes')))
        if name=='residual':
            blocks=certify_blocks(d['states'],rows,d['constraints'],(source/'ES8BlockData.lean').read_text())
            require(set(ids).isdisjoint(blocks['row_ids']) and set(ids)|set(blocks['row_ids'])==set(range(len(rows))),
                    'Residual row coverage is not a complete disjoint partition')
            report[name]['blocks']=blocks
            bad_constraints=copy.deepcopy(d['constraints'])
            bad_constraints[blocks['row_ids'][0]]['map'][0][1]=4
            rejects(lambda:certify_blocks(d['states'],rows,bad_constraints,(source/'ES8BlockData.lean').read_text()))
        compare_arithmetic(d,rows,(source/f'ES8/Certificates/{name.title()}Data.lean').read_text())
        report[name]['omission_tree']=check_tree(root/f'certificates/{name}.json')
        bad=copy.deepcopy(d);bad['nodes'][bad['root']]['one']=bad['nodes'][bad['root']]['zero']
        with tempfile.TemporaryDirectory(prefix='es8_negative_') as temp:
            path=Path(temp)/'bad.json';path.write_text(json.dumps(bad))
            rejects(lambda:check_tree(path))
        report[name]['rejection_controls']=['reversed cycle','duplicate state','incomplete branch']
        if name=='residual':report[name]['rejection_controls'].append('invalid block threshold')
    report.update(status='PASS',seconds=round(time.monotonic()-start,3),
                  scope='All ES8 finite capacity conditions and both complete omission trees; geometric transfer uses the proved lemmas.',
                  lean_or_native_evaluation_used=False)
    if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
